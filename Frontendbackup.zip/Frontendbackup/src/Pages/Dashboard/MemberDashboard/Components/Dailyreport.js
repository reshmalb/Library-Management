import "./Dailyreport.css";
const Dailyreport=()=>{
    return(
    <>
       
    <table className="activebooks-table">
                        <tr>
                            <th>S.No</th>
                            <th>Date</th>
                            <th>Student Name</th>
                            <th>Task Completed</th>
                            <th>Challege Faced</th>
                            <th>Goals for Next Day</th>
                        </tr>
            </table>
    </>  
    
    );

}
export default Dailyreport;