const Markcard=()=>{
    return(
    <>
           <table>
        <tr>
            <td><input type="text" placeholder="Title"/></td>
            <td>StartDate<input type="date" placeholder="Title"/></td>
            <td>EndDate<input type="date" placeholder="Title"/></td>
            <td>Points<input type="text" placeholder="Points"/></td>
            <td>AssignedTo<select>
                <option>All</option>
                <option>Batch1</option>
                <option>Batch2</option>
                </select></td>
                
        </tr>
        <tr>
            <td><input type="button" value="AddAssignment"/></td>
        </tr>
    </table>
    
    <table className="activebooks-table">
                        <tr>
                            <th>S.No</th>
                            <th>Title</th>
                            <th>Points</th>
                            <th>StartDate</th>
                            <th>SubmissionDate</th>
                        </tr>
            </table>
     
    </>
    );

}
export default Markcard;