import "./Messages.css"
const Messages=()=>{
    return(
        <>
        <table>
            <tr>
                <td>
            <textarea id="txtMsg" placeholder="Message" className="txtMsg" ></textarea>
                </td>
                <td>
                    Send to<br/>
                    <select>
                        <option>All</option>
                        <option>Group1</option>
                    </select>
                    <input type="button" value="Send"/  >                </td>
            </tr>
        
        </table>
        </>
    );
}
export default Messages;