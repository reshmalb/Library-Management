const Fees=()=>{
    return(
    <>
       <table>
        <tr>
            <td><input type="text" placeholder="Student Name"/></td>
            <td><input type="text" placeholder="EnrollID"/></td>
            <td><input type="text" placeholder="Amount"/></td>
            <td>RemittanceDate<input type="date" /></td>

            
                
        </tr>
        <tr>
            <td><input type="button" value="Add"/></td>
        </tr>
    </table>
    
    <table className="activebooks-table">
                        <tr>
                            <th>S.No</th>
                            <th>StudentName</th>
                            <th>EnrollID</th>
                            <th>Amount</th>
                            <th>RemittanceDate</th>
                        </tr>
            </table>  
    </>
    );

}
export default Fees;