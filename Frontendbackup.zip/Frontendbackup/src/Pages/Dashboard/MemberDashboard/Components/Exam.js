const Exam=()=>{
 return(
    <>
     <table>
        <tr>
            <td><input type="text" placeholder="Exam Title"/></td>
            <td>StartDate<input type="date" /></td>
            <td>EndDate<input type="date" /></td>
            <td>TotalMarks<input type="text" placeholder="Points"/></td>
            <td>AssignedTo<select>
                <option>All</option>
                <option>Batch1</option>
                <option>Batch2</option>
                </select></td>
                
        </tr>
        <tr>
            <td><input type="button" value="AddExam"/></td>
        </tr>
    </table>
    
    <table className="activebooks-table">
                        <tr>
                            <th>S.No</th>
                            <th>Title</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Total Marks</th>
                            <th>Assigned To</th>
                        </tr>
            </table>
    </>
    
 );   
}
export default Exam;